import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function ApiKeyDashboard() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>ApiKeyDashboard</CardTitle>
        </CardHeader>
        <CardContent>
          <p>This is the ApiKeyDashboard page. Content coming soon.</p>
        </CardContent>
      </Card>
    </div>
  );
}
