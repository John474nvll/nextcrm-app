#!/bin/bash
/ephemeral/nix/store/03h8f1wmpb86s9v8xd0lcb7jnp7nwm6l-idx-env-fhs/usr/bin/pg_ctl -D pgdata -l logfile start
